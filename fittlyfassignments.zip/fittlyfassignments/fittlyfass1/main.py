A=[1,2,3,4,5,6]
for item in A:
    print(item*item)
print("The sequence has ended")